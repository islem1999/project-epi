#include<stdio.h>
// Affiche un message de bienvenue
int main()
{
 printf ("Bienvenue le monde !");
 return 0;
}
